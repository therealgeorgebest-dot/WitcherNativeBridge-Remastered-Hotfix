f46eaf9d58cad0c73fc80832ecd9878fdd22963a892ce3a09693973e294879a1
WITCHER NATIVE BRIDGE — UNOFFICIAL REMASTERED COMPATIBILITY HOTFIX
Candidate version: 1.0 (29 October 2026)

TESTED
- User-confirmed in-game launch and expected operation on Witcher 3 Remastered executable file version 5.0.16.41566 (DX12).
- Addresses missing WitcherScript imports WNB_GetApiVersion and WNB_StringToName on that installation.
- Compatibility with other executables, DirectX 11, and all third-party native modules is NOT confirmed.

INSTALLATION (manual only; do not install the ZIP wholesale)
1. Make a copy of the existing bin\x64_dx12\WitcherNativeBridge.asi outside the game folder.
2. Extract just WitcherNativeBridge.asi from this archive.
3. Replace the existing file at bin\x64_dx12\WitcherNativeBridge.asi.
4. Keep the existing ASI loader, modNativeBridge scripts and other mods unchanged.
5. Launch the game in DX12. Check for both missing import errors and verify dependent mods work.

ROLLBACK
1. Exit the game.
2. Restore the original saved WitcherNativeBridge.asi to bin\x64_dx12\WitcherNativeBridge.asi.
3. Leave all other mods unchanged.

RELEASE STATUS / RIGHTS
- The DLL is the exact user-supplied, Visual Studio 2026-built binary reported working in-game.
- This is unofficial and not endorsed by the upstream authors.
- Upstream source: https://github.com/rejuvenate7/WitcherNativeBridge (MIT licence; see LICENSE.txt).
- Original Nexus listing states separate modification/redistribution permission restrictions. Check with the author or Nexus before publicly uploading the DLL: https://www.nexusmods.com/witcher3/mods/13743
- Disable Donation Points for this submission; credit Flawkee and rejuvenate7.

SHA-256 WitcherNativeBridge.asi:
f46eaf9d58cad0c73fc80832ecd9878fdd22963a892ce3a09693973e294879a1
